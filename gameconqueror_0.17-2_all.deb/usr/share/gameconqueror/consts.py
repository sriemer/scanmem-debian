# constants 
# should be defined by autotools

VERSION = '0.17'
LIBDIR = '/usr/lib/scanmem'
LOCALEDIR = '/usr/share/locale'
GETTEXT_PACKAGE = 'GameConqueror'
PACKAGE_BUGREPORT = 'https://github.com/scanmem/scanmem'

SETTINGS = {'scan_data_type':'int32'
           ,'lock_data_type':'int32'
           ,'search_scope'  : 1      # normal
           }
